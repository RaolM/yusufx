import { motion } from "framer-motion"
import Image from "next/image"

const products = [
  {
    name: "Pterodactyl Panel",
    description: "Powerful game server management solution for seamless hosting experiences.",
    image: "https://files.catbox.moe/skj01i.jpg",
  },
  {
    name: "WhatsApp Bot Scripts",
    description: "Automate your WhatsApp communication with our advanced bot scripts.",
    image: "https://i.ibb.co.com/DD9sLRKD/IMG-20250212-WA0015.jpg",
  },
  {
    name: "Cloud VPS",
    description: "High-performance virtual private servers from top providers.",
    image: "https://files.catbox.moe/t8tcmr.jpg",
  },
]

export default function FeaturedProducts() {
  return (
    <motion.section
      id="products"
      className="py-20 px-4 bg-gray-800"
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold mb-12 text-center">Our Featured Products</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {products.map((product, index) => (
            <motion.div
              key={index}
              className="bg-gray-700 rounded-lg overflow-hidden shadow-lg transition duration-300 ease-in-out transform hover:scale-105"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="relative h-48">
                <Image src={product.image || "/placeholder.svg"} alt={product.name} layout="fill" objectFit="cover" />
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-semibold mb-2">{product.name}</h3>
                <p className="text-gray-300">{product.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.section>
  )
}

